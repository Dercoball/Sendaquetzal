﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VerifyStatusPaymentsService
{
    public class DatosSalida
    {

        public int CodigoError;
        public String MensajeError;
        public String IdItem;
        public DateTime FechaHora;

        public string Accion;



    }
}