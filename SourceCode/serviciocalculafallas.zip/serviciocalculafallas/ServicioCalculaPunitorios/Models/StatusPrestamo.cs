﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VerifyStatusPaymentsService
{
    public class StatusPrestamo
    {


        public int IdStatusPrestamo;
        public String Nombre;
        

        public string Accion;



    }
}